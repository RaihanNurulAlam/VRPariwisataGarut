﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class MainMenu : MonoBehaviour
{
	public void CandiCangkuang()
	{
		SceneManager.LoadSceneAsync(1);
	}
	public void LeuwiTonjong()
	{
		SceneManager.LoadSceneAsync(2);
	}
	public void Sayangheulang()
	{
		SceneManager.LoadSceneAsync(3);
	}
	public void SituBagendit()
	{
		SceneManager.LoadSceneAsync(4);
	}
	public void Sagara()
	{
		SceneManager.LoadSceneAsync(5);
	}
	public void Back()
	{
		SceneManager.LoadSceneAsync(0);
	}
	public void KebunMawar()
	{
		SceneManager.LoadSceneAsync(6);
	}
	public void Papandayan()
	{
		SceneManager.LoadSceneAsync(7);
	}
	public void KaracakValley()
	{
		SceneManager.LoadSceneAsync(8);
	}
}
